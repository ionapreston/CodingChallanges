﻿using System;

namespace ReverseString2
{
    class Program
    {
        static void Main(string[] args)
        {
            var st = ReverseString.Reverse("hello world");

            Console.WriteLine(st);
        }
    }
}
