﻿using System;
namespace ReverseString2
{
    public class ReverseString
    {

        /*Reverses a string by converting a string to a char array then uses 
        the reverse function and returns it as a new string*/
        public static string Reverse(string s)
        {

            char[] reverseString = s.ToCharArray();
            Array.Reverse(reverseString);

            return new string(reverseString);

            //If wanted without using a built in method then the following could
            //be done.

            /*
             * char[] sCharArray = s.ToCharArray();
            string reverseString = String.Empty;
            for (int i = sCharArray.Length - 1; i > -1; i--)
            {
                reverseString += sCharArray[i];
            }
            return reverseString;
            */


        }
    }
}
