﻿using System;
namespace CardGame2
{
    public interface IPackOfCardsCreator
    {
       
            IPackOfCards Create();
        }
    
}
