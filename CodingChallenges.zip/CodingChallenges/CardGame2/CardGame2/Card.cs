﻿using System;
namespace CardGame2
{
   
        public class Card : ICard
        {

            public Card(Suit suit, Value value)
            {
                Suit = suit;
                Value = value;
            }

            public Suit Suit
            {
                get; 
            }

            public Value Value
            {
                get; 
            }

            //Determinds if card requested is equal to the curr card
            public bool Equals(ICard other)
            {
                return (other.Suit == Suit && other.Value == Value);
            }
        }
    
}
