﻿using System;

namespace CardGame2
{
    class Program
    {
        static void Main(string[] args)
        {

            //Creates a new pack of cards
            IPackOfCards newPack = new PackOfCardsCreator().Create();

            int choice = -1;
            //Constant loop to show program working
            while (choice != 100)
            {
                Console.WriteLine("Please select one of the following options '1','2','3','4':");
                Console.WriteLine("1. Count the number of cards in the pack.");
                Console.WriteLine("2. Print the pack");
                Console.WriteLine("3. Remove a card from top of the pack");
                Console.WriteLine("4. Shuffle the pack");

                //reads in users selection 
                choice = Convert.ToInt32(Console.ReadLine());

                //Switch statement for each option
                switch (choice)
                {
                    case 1:
                        //Prints amount in pack
                        Console.WriteLine(newPack.Count);
                        break;
                    case 2:
                        //Prints every card in the pack
                        foreach (ICard cardInPack in newPack)
                        {
                            Console.WriteLine("{0} {1}", cardInPack.Value, cardInPack.Suit);
                        }

                        break;
                    case 3:
                        //Takes card of top of stack and prints it
                        ICard card = newPack.TakeCardFromTopOfPack();
                        Console.WriteLine("{0} {1}", card.Value, card.Suit);
                        break;
                    case 4:
                        //Shuffles the pack
                        newPack.Shuffle();
                        break;

                }
            }
        }
    }
}
