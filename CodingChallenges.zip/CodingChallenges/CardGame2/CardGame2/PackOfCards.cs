﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CardGame2
{
    public class PackOfCards : IPackOfCards
    {
        //use of stack for cards for FILO
        private Stack<ICard> pack;
        //List of cards that are removed from pack
        private List<ICard> poppedCards;

        public PackOfCards(Stack<ICard> cards)
        {
            pack = cards;
            poppedCards = new List<ICard>();
        }

        /* I have assumed by the challenges instructions that every time the shuffle 
         * method ALL cards are returned to the deck (the ones removed) and then the pack
         * is shuffled.
         */
        public void Shuffle()
        {
            Random r = new Random();

            // Iterates for every popped card and puts them back onto the pack
            foreach (ICard card in poppedCards)
            {
                pack.Push(card);
            }

            //Popped cards list set back to an empty list
            poppedCards.Clear();

            

            int n = pack.Count;
            List<ICard> newPack = pack.ToList();

            /*Loop for swaping cards starting from last card
            start from the last element, swap it with a randomly selected element
            from the whole array */
            while (n > 1)
            {

                n--;
                //picks a new random index for card.
                int index = r.Next(n + 1);

                //swaps the current card with the card at the index
                ICard tempCard = newPack[index];
                newPack[index] = newPack[n];
                newPack[n] = tempCard;

            }

            pack.Clear();

            foreach (ICard card in newPack)
            {
                pack.Push(card);
            }

            /*
             Original code for shuffle:

             pack = new Stack<ICard>(pack.OrderBy(x => r.Next()));
         
            */
        }



        /* Removes the top card from the pack using 'pop' and returns it.
         * All removed cards are added to the list of removed cards.
         */
        public ICard TakeCardFromTopOfPack()
        {
            if (pack.Count > 0)
            {
                ICard topCard = pack.Pop();
                poppedCards.Add(topCard);
                return topCard;
            }
            else
            {
                return null;
            }
        }

        //Gets the length of the stack.
        public int Count
        {
            get
            {
                return pack.Count();
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        { 
            return pack.GetEnumerator();
        }

        public IEnumerator<ICard> GetEnumerator()
        {
            return pack.GetEnumerator();


        }

    }
}
