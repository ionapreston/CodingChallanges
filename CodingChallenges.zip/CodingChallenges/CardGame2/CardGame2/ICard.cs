﻿using System;
namespace CardGame2
{
        public interface ICard : IEquatable<ICard>
        {
            Suit Suit { get; }

            Value Value { get;  }

        }
    }
