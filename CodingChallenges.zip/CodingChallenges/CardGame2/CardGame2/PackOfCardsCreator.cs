﻿using System;
using System.Collections.Generic;

namespace CardGame2
{
    public class PackOfCardsCreator : IPackOfCardsCreator
    {
        

        /* Creates a non shuffled pack of cards.
        Nested foreach loops create all the new cards with every value and suit.
        Returns the created pack.
        */

        public IPackOfCards Create()
        {
            
            Stack<ICard> pack = new Stack<ICard>();

            foreach (Suit s in (Suit[])Enum.GetValues(typeof(Suit)))
            {
                foreach (Value v in (Value[])Enum.GetValues(typeof(Value)))
                {

                    ICard card = new Card(s, v);
                    pack.Push(card);
                


                }
            }


            return new PackOfCards(pack);
        }
    }
}
