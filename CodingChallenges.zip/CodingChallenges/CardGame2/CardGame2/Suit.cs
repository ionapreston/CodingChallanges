﻿using System;
namespace CardGame2
{
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
