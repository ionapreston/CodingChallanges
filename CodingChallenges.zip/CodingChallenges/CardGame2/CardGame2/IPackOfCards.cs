﻿using System;
using System.Collections.Generic;

namespace CardGame2
{
    public interface IPackOfCards : IReadOnlyCollection<ICard>
    {
        void Shuffle();

        ICard TakeCardFromTopOfPack();


    }
}
